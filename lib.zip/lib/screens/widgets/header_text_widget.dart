import 'package:flutter/material.dart';
import 'package:portfolio/constants/colors.dart';
import 'package:portfolio/screens/widgets/download_cv_widget.dart';
import 'package:portfolio/screens/widgets/social_widgets.dart';
import 'package:portfolio/screens/widgets/text_widgets.dart';
import 'package:simple_gradient_text/simple_gradient_text.dart';

class HeaderTextWidget extends StatelessWidget {
  final Size size;

  const HeaderTextWidget({
    super.key,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(
        horizontal: size.width * 0.07,
      ),
      child: Column(
        crossAxisAlignment:
            size.width > 600 ? CrossAxisAlignment.start : CrossAxisAlignment.center,
        children: [
          TextWidget(
            sSize: size,
            text: "Hi, I'm Adrija Ghosh",
            color: Colors.white,
            size: 26,
            fw: FontWeight.bold,
            alignment: TextAlign.center,
          ),

          const SizedBox(height: 10),

          GradientTextWidget(
            size: size,
            alignment: TextAlign.center,
            text1: "Flutter Developer",
            text2: "BCA Student",
          ),

          const SizedBox(height: 20),

          SizedBox(
            width: size.width * 0.5,
            child: TextWidget(
              sSize: size,
              alignment: TextAlign.center,
              text:
                  "Passionate Flutter developer focused on building beautiful, responsive, and user-friendly cross-platform applications. I enjoy turning ideas into modern digital experiences.",
              size: 16,
              color: Colors.white70,
              fw: FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}

class GradientTextWidget extends StatelessWidget {
  final Size size;
  final TextAlign? alignment;
  final String? text1;
  final String? text2;

  const GradientTextWidget({
    super.key,
    required this.size,
    this.alignment,
    this.text1,
    this.text2,
  });

  @override
  Widget build(BuildContext context) {
    return GradientText(
      "${text1 ?? ""}\n${text2 ?? ""}",
      textAlign: size.width < 600 ? alignment : null,
      colors: const [
        // ignore: dead_null_aware_expression
        AppColors.studio ?? Colors.white,
        AppColors.paleSlate,
      ],
      style: TextStyle(
        fontSize: size.width > 950
            ? 42
            : size.width > 600
                ? 34
                : 28,
        fontWeight: FontWeight.bold,
        fontFamily: 'Poppins',
      ),
    );
  }
}

class SocialLarge extends StatelessWidget {
  final Size size;

  const SocialLarge({
    super.key,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size.width * 0.5,
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          DownloadCVButton(),
          SizedBox(width: 20),
          SocialWidget(),
        ],
      ),
    );
  }
}