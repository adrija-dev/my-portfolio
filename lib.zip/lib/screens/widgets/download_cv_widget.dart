import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:portfolio/constants/colors.dart';


class DownloadCVButton extends StatelessWidget {
  const DownloadCVButton({super.key});

  Future<void> _downloadCV() async {
    final Uri url = Uri.parse('assets/cv/Adrija_Ghosh_Resume.pdf');

    if (!await launchUrl(url, webOnlyWindowName: '_blank')) {
      throw Exception('Could not open CV');
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: _downloadCV,
      child: Container(
        height: 50,
        width: 250,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.paleSlate),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Download CV",
              style: TextStyle(color: AppColors.paleSlate),
            ),
            SizedBox(width: 12),
            FaIcon(
              FontAwesomeIcons.download,
              color: AppColors.paleSlate,
              size: 18,
            ),
          ],
        ),
      ),
    );
  }
}