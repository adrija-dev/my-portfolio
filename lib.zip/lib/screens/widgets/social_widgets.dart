import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:portfolio/constants/colors.dart';
import 'package:url_launcher/url_launcher.dart';

class SocialWidget extends StatelessWidget {
  const SocialWidget({super.key});

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);

    if (!await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    )) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SocialIcon(
          icon: FontAwesomeIcons.linkedinIn,
          onTap: () => _launchUrl(
            'https://www.linkedin.com/in/adrija-ghosh20',
          ),
        ),
        const SizedBox(width: 10),

        SocialIcon(
          icon: FontAwesomeIcons.github,
          onTap: () => _launchUrl(
            'https://github.com/adrija-dev',
          ),
        ),
        const SizedBox(width: 10),

        SocialIcon(
          icon: FontAwesomeIcons.envelope,
          onTap: () => _launchUrl(
            'mailto:adrijaghosh5002@gmail.com',
          ),
        ),
        const SizedBox(width: 10),

        SocialIcon(
          icon: FontAwesomeIcons.globe,
          onTap: () => _launchUrl(
            'https://yourportfolio.com',
          ),
        ),
      ],
    );
  }
}

class SocialIcon extends StatelessWidget {
  final FaIconData icon;
  final VoidCallback onTap;

  const SocialIcon({
    super.key,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      width: 40,
      decoration: BoxDecoration(
        color: Colors.transparent,
        shape: BoxShape.circle,
        border: Border.all(
          color: AppColors.studio.withValues(alpha: 0.5),
        ),
      ),
      child: IconButton(
        onPressed: onTap,
        hoverColor: AppColors.paleSlate,
        splashRadius: 22,
        icon: FaIcon(
          icon,
          color: AppColors.studio,
          size: 16,
        ),
      ),
    );
  }
}