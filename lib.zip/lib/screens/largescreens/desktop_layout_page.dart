import 'package:flutter/material.dart';
import 'package:portfolio/constants/colors.dart';
import 'package:portfolio/constants/styles.dart';
import 'package:portfolio/screens/tablets/tablet_layout_page.dart';
import 'package:portfolio/screens/widgets/count_container_widgets.dart';
import 'package:portfolio/screens/widgets/header_text_widget.dart';
import 'package:portfolio/screens/widgets/myservice_widget.dart';
import 'package:portfolio/screens/widgets/rotating_image_widget.dart';
import 'package:simple_gradient_text/simple_gradient_text.dart';

class DesktopLayout extends StatefulWidget {
  const DesktopLayout({super.key});

  @override
  State<DesktopLayout> createState() => _DesktopLayoutState();
}

class _DesktopLayoutState extends State<DesktopLayout> {
  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: Styles.gradientDecoration,
        child: SingleChildScrollView(
          child: Column(
            children: [
              
              Container(
                margin: EdgeInsets.symmetric(
                  vertical: size.height * 0.18,
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        HeaderTextWidget(size: size),

                        const SizedBox(height: 20),

                        SocialLarge(size: size),
                      ],
                    ),

                    const Expanded(
                      child: Center(
                        child: RotatingImageContainer(),
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                margin: EdgeInsets.symmetric(
                  horizontal: size.width * 0.05,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    CountWidget(
                      size: size,
                      text1: "2+",
                      text2: "Projects",
                      text3: "Completed",
                    ),

                    CountWidget(
                      size: size,
                      text1: "10+",
                      text2: "Technologies",
                      text3: "Learned",
                    ),

                    CountWidget(
                      size: size,
                      text1: "100%",
                      text2: "Passion",
                      text3: "For Coding",
                    ),
                  ],
                ),
              ),

              SizedBox(height: size.height * 0.12),

              /// ================= SERVICES =================
              Container(
                width: double.infinity,
                color: AppColors.ebony,
                padding: EdgeInsets.symmetric(
                  vertical: size.width * 0.05,
                ),
                child: Column(
                  children: [
                    GradientText(
                      "Services",
                      style: TextStyle(
                        fontSize: size.width * 0.03,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.bold,
                      ),
                      colors: const [
                        Colors.white,
                        Colors.blueAccent,
                      ],
                    ),

                    SizedBox(height: size.height * 0.02),

                    Text(
                      "I build modern, responsive, and user-friendly Flutter applications with clean UI and smooth user experiences.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: size.width * 0.012,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                      ),
                    ),

                    SizedBox(height: size.height * 0.05),

                    MyServicesWidget(size: size),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}